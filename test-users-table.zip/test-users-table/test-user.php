<?php
/*
 * Plugin Name: Test
 * Plugin URI: 
 * Description: Use the shortcode: [test-users]
 * Version: 0.0.1
 * Author: Dmitrii Zabolotskii
 * Author URI:
 * License: 
 */

if ( !function_exists('wp_get_current_user') ) {
	include(ABSPATH . "wp-includes/pluggable.php"); 
}

add_action('wp_enqueue_scripts', 'font_awesome');
function font_awesome() {
	if (!is_admin()) {
		wp_register_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css');
		wp_enqueue_style('font-awesome');
		}
	}

wp_enqueue_style( 'my-css', plugins_url('/css/my-css.css', __FILE__) );
wp_enqueue_script( 'myjquery', plugins_url('myjquery.js', __FILE__ ), array('jquery') );


$current_user = wp_get_current_user();

if ($current_user->has_cap('administrator')) {

	function test_users_fn() {
		
		$blogusers = get_users( $sort );?>
			<table id="#mytable" class="test-table">
				<thead>
					<tr>
						<th><div class="col-head"><i class="sort-btn fa fa-sort-amount-down"></i>ID</div></th>
						<th><div class="col-head"><i class="sort-btn fa fa-sort-amount-down"></i>Name</div></th>
						<th><div class="col-head"><i class="sort-btn fa fa-sort-amount-down"></i>Email</div></th>
						<th><div class="col-head"><i class="sort-btn fa fa-sort-amount-down"></i>Role</div></th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach ($blogusers as $user) {
						echo '<tr>';
							echo '<td>' . $user->ID . '</td>';
							echo '<td>' . $user->display_name . '</td>';
							echo '<td>' . $user->user_email .  '</td>';
							echo '<td>' . implode(', ', $user->roles) . '</td>';
						echo '</tr>';
					} ?>
				</tbody> 
			</table> <?php
		}
	
	} 

else {                                 
	function test_users_fn(){
		echo 'You are NOT admin';
	}    
}

add_shortcode('test-users', 'test_users_fn');
?>